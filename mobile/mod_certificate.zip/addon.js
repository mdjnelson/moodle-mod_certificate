angular.module('mm.addons.mod_certificate', [])

.constant('mmaModCertificateComponent', 'mmaModCertificate')

.config(function($stateProvider) {

    $stateProvider

    .state('site.mod_certificate', {
        url: '/mod_certificate',
        params: {
            module: null,
            courseid: null
        },
        views: {
            'site': {
                controller: 'mmaModCertificateIndexCtrl',
                templateUrl: '$ADDONPATH$/templates/index.html'
            }
        }
    });

})

.config(function($mmCourseDelegateProvider, $mmContentLinksDelegateProvider) {
    $mmCourseDelegateProvider.registerContentHandler('mmaModCertificate', 'certificate', '$mmaModCertificateHandlers.courseContent');
    $mmContentLinksDelegateProvider.registerLinkHandler('mmaModCertificate', '$mmaModCertificateHandlers.linksHandler');
});

angular.module('mm.addons.mod_certificate')

/**
 * Certificate index controller.
 *
 * @module mm.addons.mod_certificate
 * @ngdoc controller
 * @name mmaModCertificateIndexCtrl
 */
.controller('mmaModCertificateIndexCtrl', function($scope, $stateParams, $mmaModCertificate, $mmUtil, $q, $mmCourse) {
    var module = $stateParams.module || {},
        courseid = $stateParams.courseid,
        certificate;

    $scope.title = module.name;
    $scope.description = module.description;
    $scope.courseid = courseid;

    // Convenience function to get Certificate data.
    function fetchCertificate(refresh) {
        return $mmaModCertificate.getCertificate(courseid, module.id).then(function(certificatedata) {
            certificate = certificatedata;
            $scope.title = certificate.name || $scope.title;
            $scope.description = certificate.intro || $scope.description;
            $scope.certificate = certificate;

            // Requeriments for issue certificates not met yet, ommit try to download already issued certificates.
            if (certificate.requiredtimenotmet) {
                return $q.when();
            }

            // Every time we access we call the issue certificate WS, this may fail if the user is connected, so we must retrieve
            // the issued certificate to use the cache on failure.
            return $mmaModCertificate.issueCertificate(certificate.id).finally(function() {
                return $mmaModCertificate.getIssuedCertificates(certificate.id).then(function(issues) {
                    $scope.issues = issues;
                });
            });
        }).catch(function(message) {
            if (!refresh) {
                // Some call failed, retry without using cache since it might be a new activity.
                return refreshAllData();
            }

            if (message) {
                $mmUtil.showErrorModal(message);
            } else {
                $mmUtil.showErrorModal('Error while getting the certificate', true);
            }
            return $q.reject();
        });
    }

    // Convenience function to refresh all the data.
    function refreshAllData() {
        var p1 = $mmaModCertificate.invalidateCertificate(courseid),
            p2 = certificate ? $mmaModCertificate.invalidateIssuedCertificates(certificate.id) : $q.when();
            p3 = $mmaModCertificate.invalidateDownloadedCertificates(module.id);

        return $q.all([p1, p2, p3]).finally(function() {
            return fetchCertificate(true);
        });
    }

    $scope.downloadCertificate = function() {

        var modal = $mmUtil.showModalLoading();

        // Extract the first issued, file URLs are always the same.
        var issuedCertificate = $scope.issues[0];

        $mmaModCertificate.downloadCertificate(issuedCertificate, module.id)
        .catch(function(error) {
            if (error && typeof error == 'string') {
                $mmUtil.showErrorModal(error);
            } else {
                $mmUtil.showErrorModal('Error while downloading the certificate', true);
            }
        }).finally(function() {
            modal.dismiss();
        });
    };

    fetchCertificate().then(function() {
        $mmaModCertificate.logView(certificate.id).then(function() {
            $mmCourse.checkModuleCompletion(courseid, module.completionstatus);
        });
    }).finally(function() {
        $scope.certificateLoaded = true;
    });

    // Pull to refresh.
    $scope.doRefresh = function() {
        refreshAllData().finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

});

angular.module('mm.addons.mod_certificate')

/**
 * Certificate service.
 *
 * @module mm.addons.mod_certificate
 * @ngdoc service
 * @name $mmaModCertificate
 */
.factory('$mmaModCertificate', function($q, $mmSite, $mmFS, $mmUtil, $mmSitesManager, mmaModCertificateComponent, $mmFilepool) {
    var self = {};

    /**
     * Get a Certificate.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#getCertificate
     * @param {Number} courseId Course ID.
     * @param {Number} cmid     Course module ID.
     * @return {Promise}        Promise resolved when the Certificate is retrieved.
     */
    self.getCertificate = function(courseId, cmid) {
        var params = {
                courseids: [courseId]
            },
            preSets = {
                cacheKey: getCertificateCacheKey(courseId)
            };

        return $mmSite.read('mod_certificate_get_certificates_by_courses', params, preSets).then(function(response) {
            if (response.certificates) {
                var currentCertificate;
                angular.forEach(response.certificates, function(certificate) {
                    if (certificate.coursemodule == cmid) {
                        currentCertificate = certificate;
                    }
                });
                if (currentCertificate) {
                    return currentCertificate;
                }
            }
            return $q.reject();
        });
    };

    /**
     * Get cache key for Certificate data WS calls.
     *
     * @param {Number} courseId Course ID.
     * @return {String}         Cache key.
     */
    function getCertificateCacheKey(courseId) {
        return 'mmaModCertificate:certificate:' + courseId;
    }

    /**
     * Get issued certificates.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#getIssuedCertificates
     * @param {Number} id Certificate ID.
     * @return {Promise}  Promise resolved when the issued data is retrieved.
     */
    self.getIssuedCertificates = function(id) {
        var params = {
                certificateid: id
            },
            preSets = {
                cacheKey: getIssuedCertificatesCacheKey(id)
            };

        return $mmSite.read('mod_certificate_get_issued_certificates', params, preSets).then(function(response) {
            if (response.issues) {
                return response.issues;
            }
            return $q.reject();
        });
    };

    /**
     * Get cache key for Certificate issued data WS calls.
     *
     * @param {Number} id Certificate ID.
     * @return {String}   Cache key.
     */
    function getIssuedCertificatesCacheKey(id) {
        return 'mmaModCertificate:issued:' + id;
    }

    /**
     * Invalidates Certificate data.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#invalidateCertificate
     * @param {Number} courseId Course ID.
     * @return {Promise}        Promise resolved when the data is invalidated.
     */
    self.invalidateCertificate = function(courseId) {
        return $mmSite.invalidateWsCacheForKey(getCertificateCacheKey(courseId));
    };

    /**
     * Invalidates issues certificates.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#invalidateIssuedCertificates
     * @param {Number} id Certificate ID.
     * @return {Promise}  Promise resolved when the data is invalidated.
     */
    self.invalidateIssuedCertificates = function(id) {
        return $mmSite.invalidateWsCacheForKey(getIssuedCertificatesCacheKey(id));
    };

    /**
     * Return whether or not the plugin is enabled in a certain site. Plugin is enabled if the certificate WS are available.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#isPluginEnabled
     * @param  {String} [siteId] Site ID. If not defined, current site.
     * @return {Promise}         Promise resolved with true if plugin is enabled, rejected or resolved with false otherwise.
     */
    self.isPluginEnabled = function(siteId) {
        siteId = siteId || $mmSite.getId();

        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.wsAvailable('mod_certificate_get_certificates_by_courses');
        });
    };

    /**
     * Report the Certificate as being viewed.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#logView
     * @param {String} id Certificate ID.
     * @return {Promise}  Promise resolved when the WS call is successful.
     */
    self.logView = function(id) {
        if (id) {
            var params = {
                certificateid: id
            };
            return $mmSite.write('mod_certificate_view_certificate', params);
        }
        return $q.reject();
    };

    /**
     * Issue a certificate.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#issueCertificate
     * @param {Number} certificateId Certificate ID.
     * @return {Promise}  Promise resolved when the WS call is successful.
     */
    self.issueCertificate = function(certificateId) {
         var params = {
            certificateid: certificateId
        };
        return $mmSite.write('mod_certificate_issue_certificate', params).then(function(response) {
            if (!response || !response.issue) {
                return $q.reject();
            }
        });
    };

    /**
     * Download or open a downloaded certificate.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#downloadCertificate
     * @param {Object} issuedCertificate Issued certificate object.
     * @param {Number} moduleId Module id.
     * @return {Promise}  Promise resolved when the WS call is successful.
     */
    self.downloadCertificate = function(issuedCertificate, moduleId) {

        var siteId = $mmSite.getId(),
            revision = 0,
            timeMod = issuedCertificate.timecreated,
            files = [{fileurl: issuedCertificate.fileurl, filename: issuedCertificate.filename}];

        if ($mmFS.isAvailable()) {
            // The file system is available.
            promise = $mmFilepool.downloadPackage(siteId, files, mmaModCertificateComponent, moduleId, revision, timeMod).then(function() {
                return $mmFilepool.getUrlByUrl(siteId, issuedCertificate.fileurl, mmaModCertificateComponent, moduleId, timeMod);
            });
        } else {
            // We use the live URL.
            promise = $q.when($mmSite.fixPluginfileURL(url));
        }

        return promise.then(function(localUrl) {
            return $mmUtil.openFile(localUrl);
        });
    };

    /**
     * Invalidate downloaded certificates.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificate#invalidateDownloadedCertificates
     * @param {Number} moduleId Module id.
     * @return {Promise}  Promise resolved when the WS call is successful.
     */
    self.invalidateDownloadedCertificates = function(moduleId) {
        return $mmFilepool.invalidateFilesByComponent($mmSite.getId(), mmaModCertificateComponent, moduleId);
    };

    return self;
});

angular.module('mm.addons.mod_certificate')

/**
 * Mod Certificate handler.
 *
 * @module mm.addons.mod_certificate
 * @ngdoc service
 * @name $mmaModCertificateHandlers
 */
.factory('$mmaModCertificateHandlers', function($mmCourse, $mmaModCertificate, $state, $q) {
    var self = {};

    /**
     * Course content handler.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificateHandlers#courseContent
     */
    self.courseContent = function() {
        var self = {};

        /**
         * Whether or not the module is enabled for the site.
         *
         * @return {Boolean}
         */
        self.isEnabled = function() {
            return $mmaModCertificate.isPluginEnabled();
        };

        /**
         * Get the controller.
         *
         * @param {Object} module The module info.
         * @param {Number} courseid The course ID.
         * @return {Function}
         */
        self.getController = function(module, courseid) {
            return function($scope) {
                $scope.title = module.name;
                $scope.icon = '$ADDONPATH$/icon.gif';
                $scope.class = 'mma-mod_certificate-handler';
                $scope.action = function() {
                    $state.go('site.mod_certificate', {module: module, courseid: courseid});
                };
            };
        };

        return self;
    };

    /**
     * Content links handler.
     *
     * @module mm.addons.mod_certificate
     * @ngdoc method
     * @name $mmaModCertificateHandlers#linksHandler
     */
    self.linksHandler = function() {

        var self = {};

        /**
         * Whether or not the handler is enabled for a certain site.
         *
         * @param  {String} siteId     Site ID.
         * @param  {Number} [courseId] Course ID related to the URL.
         * @return {Promise}           Promise resolved with true if enabled.
         */
        function isEnabled(siteId, courseId) {
            return $mmaModCertificate.isPluginEnabled(siteId).then(function(enabled) {
                if (!enabled) {
                    return false;
                }
                return courseId || $mmCourse.canGetModuleWithoutCourseId(siteId);
            });
        }

        /**
         * Get actions to perform with the link.
         *
         * @param {String[]} siteIds  Site IDs the URL belongs to.
         * @param {String} url        URL to treat.
         * @param {Number} [courseId] Course ID related to the URL.
         * @return {Promise}          Promise resolved with the list of actions.
         *                            See {@link $mmContentLinksDelegate#registerLinkHandler}.
         */
        self.getActions = function(siteIds, url, courseId) {
            // Check it's a Certificate URL.
            if (typeof self.handles(url) != 'undefined') {
                return $mmContentLinksHelper.treatModuleIndexUrl(siteIds, url, isEnabled, courseId);
            }
            return $q.when([]);
        };

        /**
         * Check if the URL is handled by this handler. If so, returns the URL of the site.
         *
         * @param  {String} url URL to check.
         * @return {String}     Site URL. Undefined if the URL doesn't belong to this handler.
         */
        self.handles = function(url) {
            var position = url.indexOf('/mod/certificate/view.php');
            if (position > -1) {
                return url.substr(0, position);
            }
        };

        return self;
    };

    return self;
});

